# 3D-Inverse-Kinematics

C++ OpenGL application implementing Inverse Kinematics on a linkage of 3 joints and 9 degrees of freedom using Jacobian Transpose method

![ezgif-6-aca5d1a3b9e4](https://user-images.githubusercontent.com/37753430/72993717-7a677280-3dbb-11ea-9a24-4840f85a35d3.gif)
